import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiKeys {
  static const String wgerBaseUrl = 'https://wger.de/api/v2';
  // static const String groqApiKey =
  //     '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';
  static final groqApiKey = dotenv.env['groqApiKey'];
}
