import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/repositories/auth_repository.dart';

class AuthState {
  final bool isLoading;
  final String? errorMessage;
  final User? currentUser;

  AuthState({
    this.isLoading = false,
    this.errorMessage,
    this.currentUser,
  });

  AuthState copyWith({
    bool? isLoading,
    String? errorMessage,
    User? currentUser,
  }) {
    return AuthState(
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage, // We want to be able to set it to null explicitly by returning null if not provided? No, Riverpod typical copyWith handles nulls carefully. For now let's just make it assign directly or clear it if it's not the same.
      // Better copyWith for nullable errorMessage:
      // In this simple case, we'll just define it where we either pass errorMessage or a 'clearError' flag.
      // Or simpler: always pass it if there's an error, otherwise clear it.
    );
  }
}

// Need a specific copyWith to handle nullable fields properly
extension AuthStateExtension on AuthState {
  AuthState copyWith({
    bool? isLoading,
    String? errorMessage,
    User? currentUser,
    bool clearError = false,
  }) {
    return AuthState(
      isLoading: isLoading ?? this.isLoading,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      currentUser: currentUser ?? this.currentUser,
    );
  }
}

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository();
});

final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(ref.watch(authRepositoryProvider));
});

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _authRepository;

  AuthNotifier(this._authRepository) : super(AuthState(currentUser: _authRepository.currentUser)) {
    // Listen to Firebase auth state changes
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      state = state.copyWith(currentUser: user, clearError: true);
    });
  }

  Future<bool> signInWithEmail(String email, String password) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      await _authRepository.signInWithEmail(email, password);
      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<bool> signUpWithEmail(String email, String password, String name) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      await _authRepository.signUpWithEmail(email, password, name);
      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<bool> signInWithGoogle() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final credential = await _authRepository.signInWithGoogle();
      state = state.copyWith(isLoading: false);
      return credential != null;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<bool> sendPasswordResetEmail(String email) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      await _authRepository.sendPasswordResetEmail(email);
      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  Future<void> signOut() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      await _authRepository.signOut();
      state = state.copyWith(isLoading: false, currentUser: null);
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }

  Future<bool> hasCompletedProfile() async {
    final user = state.currentUser;
    if (user == null) return false;
    return await _authRepository.hasCompletedProfile(user.uid);
  }

  void clearError() {
    state = state.copyWith(clearError: true);
  }
}
